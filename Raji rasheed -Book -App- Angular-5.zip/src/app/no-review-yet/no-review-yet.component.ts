import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-review-yet',
  templateUrl: './no-review-yet.component.html',
  styleUrls: ['./no-review-yet.component.css']
})
export class NoReviewYetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
