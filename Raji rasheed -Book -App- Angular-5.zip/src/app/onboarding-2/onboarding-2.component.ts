import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onboarding-2',
  templateUrl: './onboarding-2.component.html',
  styleUrls: ['./onboarding-2.component.css']
})
export class Onboarding2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
